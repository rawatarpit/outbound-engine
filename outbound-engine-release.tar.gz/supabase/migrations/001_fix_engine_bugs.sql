-- ========================================================
-- Outbound Engine - Backend Bug Fixes Migration
-- File: supabase/migrations/001_fix_engine_bugs.sql
-- Generated: April 2026
-- ========================================================

-- ========================================================
-- B01: Remove Duplicate Client-Creation Triggers
-- From: Supabase_Snippet_List_Database_Triggers.csv
-- ========================================================
DROP TRIGGER IF EXISTS on_new_client ON public.clients;
DROP TRIGGER IF EXISTS trigger_handle_new_client ON public.clients;

-- ========================================================
-- B03: Fix handle_new_client() Wrong Schema
-- Must recreate trigger after fixing the function
-- Use CASCADE to drop trigger dependency
-- ========================================================
DROP FUNCTION IF EXISTS public.handle_new_client() CASCADE;

CREATE OR REPLACE FUNCTION public.handle_new_client()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO system_flags (client_id, key, value)
  VALUES 
    (NEW.id, 'automation_enabled', true),
    (NEW.id, 'send_enabled', true),
    (NEW.id, 'imap_enabled', false),
    (NEW.id, 'discovery_enabled', true)
  ON CONFLICT (client_id, key) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_handle_new_client
  AFTER INSERT ON public.clients
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_client();

-- ========================================================
-- B04: Fix rpc_insert_reply() Wrong Column Names
-- ========================================================
DROP FUNCTION IF EXISTS public.rpc_insert_reply(uuid, uuid, text, text, text);

CREATE OR REPLACE FUNCTION public.rpc_insert_reply(
  p_company_id uuid, 
  p_lead_id uuid, 
  p_message_id text, 
  p_body text, 
  p_subject text
) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO replies (company_id, message_id, raw_message, brand_id)
  SELECT p_company_id, p_message_id, p_body, brand_id
  FROM companies WHERE id = p_company_id
  ON CONFLICT (message_id) DO NOTHING;
  RETURN FOUND;
END;
$$;

-- ========================================================
-- B05: Fix rpc_insert_negotiation_draft() Wrong Columns
-- ========================================================
DROP FUNCTION IF EXISTS public.rpc_insert_negotiation_draft(uuid, text);

CREATE OR REPLACE FUNCTION public.rpc_insert_negotiation_draft(
  p_company_id uuid, 
  p_draft text
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_brand_id uuid;
  v_lead_id uuid;
BEGIN
  SELECT brand_id INTO v_brand_id FROM public.companies WHERE id = p_company_id;
  
  SELECT lead_id INTO v_lead_id 
  FROM public.lead_company_map 
  WHERE company_id = p_company_id 
  LIMIT 1;

  INSERT INTO public.messages (brand_id, lead_id, body, direction, status)
  VALUES (v_brand_id, v_lead_id, p_draft, 'outbound', 'pending');
END;
$$;

-- ========================================================
-- B06: Add contacted_at column to leads table
-- ========================================================
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'leads' AND column_name = 'contacted_at'
  ) THEN
    ALTER TABLE public.leads ADD COLUMN contacted_at timestamp with time zone;
  END IF;
END $$;

-- ========================================================
-- B07: Fix rpc_activate_scoring_version() Uses Wrong Column
-- ========================================================
DROP FUNCTION IF EXISTS public.rpc_activate_scoring_version(uuid);

CREATE OR REPLACE FUNCTION public.rpc_activate_scoring_version(p_version_id uuid)
RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  UPDATE scoring_versions
  SET is_active = false
  WHERE brand_id = (SELECT brand_id FROM scoring_versions WHERE id = p_version_id);
  
  UPDATE scoring_versions
  SET is_active = true
  WHERE id = p_version_id;
END;
$$;

-- ========================================================
-- B08 & B09: Add domain and bounce_count to send_counters
-- ========================================================
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'send_counters' AND column_name = 'domain'
  ) THEN
    ALTER TABLE public.send_counters ADD COLUMN domain text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'send_counters' AND column_name = 'bounce_count'
  ) THEN
    ALTER TABLE public.send_counters ADD COLUMN bounce_count integer DEFAULT 0;
  END IF;
END $$;

-- ========================================================
-- B10: Add disabled_reason and disabled_at to sending_domains
-- ========================================================
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sending_domains' AND column_name = 'disabled_reason'
  ) THEN
    ALTER TABLE public.sending_domains ADD COLUMN disabled_reason text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sending_domains' AND column_name = 'disabled_at'
  ) THEN
    ALTER TABLE public.sending_domains ADD COLUMN disabled_at timestamp with time zone;
  END IF;
END $$;

-- ========================================================
-- B13: Add brand_id and unique index for circuit_breaker_state
-- ========================================================
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'circuit_breaker_state' AND column_name = 'brand_id'
  ) THEN
    ALTER TABLE public.circuit_breaker_state ADD COLUMN brand_id uuid;
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS circuit_breaker_brand_unique 
ON public.circuit_breaker_state(brand_id) 
WHERE brand_id IS NOT NULL;

-- ========================================================
-- B16: Fix rpc_adjust_scoring_weights() Wrong Source
-- ========================================================
DROP FUNCTION IF EXISTS public.rpc_adjust_scoring_weights();

CREATE OR REPLACE FUNCTION public.rpc_adjust_scoring_weights()
RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  v_config jsonb;
  v_row RECORD;
BEGIN
  FOR v_row IN SELECT brand_id FROM public.scoring_versions WHERE is_active = true LOOP
    SELECT scoring_config INTO v_config 
    FROM public.scoring_versions 
    WHERE brand_id = v_row.brand_id AND is_active = true
    LIMIT 1;

    IF v_config IS NOT NULL THEN
      UPDATE public.scoring_versions 
      SET scoring_config = v_config 
      WHERE brand_id = v_row.brand_id AND is_active = true;
    END IF;
  END LOOP;
END;
$$;

-- ========================================================
-- B17: Fix rpc_recalibrate_lead_confidence() Wrong Column
-- ========================================================
DROP FUNCTION IF EXISTS public.rpc_recalibrate_lead_confidence(uuid, numeric);

CREATE OR REPLACE FUNCTION public.rpc_recalibrate_lead_confidence(
  p_lead_id uuid, 
  p_new_confidence numeric
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE public.leads
  SET confidence_score = p_new_confidence, last_outcome_at = now()
  WHERE id = p_lead_id;
END;
$$;

-- ========================================================
-- B18: Fix rpc_increment_company_retry() Missing Columns
-- ========================================================
DROP FUNCTION IF EXISTS public.rpc_increment_company_retry(uuid, text);

CREATE OR REPLACE FUNCTION public.rpc_increment_company_retry(
  p_id uuid, 
  p_error text
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO dead_letters (brand_id, entity_id, entity_type, failure_stage, error_message, retry_count)
  SELECT brand_id, id, 'company', status, p_error, retry_count
  FROM discovered_companies WHERE id = p_id;
END;
$$;

-- ========================================================
-- B11: Create missing reserve_send_quota function
-- ========================================================
DROP FUNCTION IF EXISTS public.reserve_send_quota(uuid, text);

CREATE OR REPLACE FUNCTION public.reserve_send_quota(
  p_brand_id uuid, 
  p_domain text
) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_daily_ok boolean;
  v_hourly_ok boolean;
BEGIN
  SELECT allowed INTO v_daily_ok 
  FROM rpc_reserve_daily_send(p_brand_id);
  
  SELECT allowed INTO v_hourly_ok 
  FROM rpc_reserve_hourly_send(p_brand_id);
  
  RETURN v_daily_ok AND v_hourly_ok;
END;
$$;

-- ========================================================
-- Create get_send_quota_status wrapper
-- ========================================================
DROP FUNCTION IF EXISTS public.get_send_quota_status(uuid, text);

CREATE OR REPLACE FUNCTION public.get_send_quota_status(
  p_brand_id uuid, 
  p_domain text
) RETURNS TABLE(
  daily_sent bigint, 
  daily_limit bigint, 
  hourly_sent bigint, 
  hourly_limit bigint,
  bounce_rate numeric,
  complaint_rate numeric
) LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COALESCE(dst.send_count, 0)::bigint,
    COALESCE(bp.daily_send_limit, 1000)::bigint,
    COALESCE(dst.send_count, 0)::bigint,
    COALESCE(bp.hourly_send_limit, 100)::bigint,
    CASE WHEN COALESCE(dst.send_count, 0) > 0 
         THEN COALESCE(dst.bounce_count, 0)::numeric / dst.send_count 
         ELSE 0 END,
    0::numeric
  FROM brand_profiles bp
  LEFT JOIN LATERAL (
    SELECT send_count, bounce_count
    FROM send_counters 
    WHERE brand_id = p_brand_id
    ORDER BY created_at DESC
    LIMIT 1
  ) dst ON true
  WHERE bp.id = p_brand_id;
END;
$$;

-- ========================================================
-- Create missing get_domain_health using sending_domains
-- ========================================================
DROP FUNCTION IF EXISTS public.get_domain_health(uuid, text);

CREATE OR REPLACE FUNCTION public.get_domain_health(
  p_brand_id uuid, 
  p_domain text
) RETURNS TABLE(
  bounce_rate numeric,
  complaint_rate numeric,
  daily_sent bigint,
  daily_limit bigint,
  hourly_sent bigint,
  hourly_limit bigint
) LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  RETURN QUERY
  SELECT 
    CASE WHEN COALESCE(sd.sent_today, 0) > 0 
         THEN sd.bounce_count::numeric / sd.sent_today 
         ELSE 0 END,
    0::numeric,
    COALESCE(sd.sent_today, 0)::bigint,
    COALESCE(sd.daily_limit, 1000)::bigint,
    0::bigint,
    0::bigint
  FROM sending_domains sd
  WHERE sd.brand_id = p_brand_id AND sd.domain = p_domain AND sd.is_active = true;
END;
$$;

-- ========================================================
-- Fix register_domain_bounce
-- ========================================================
DROP FUNCTION IF EXISTS public.register_domain_bounce(uuid, text, boolean);

CREATE OR REPLACE FUNCTION public.register_domain_bounce(
  p_brand_id uuid, 
  p_domain text, 
  p_is_hard boolean DEFAULT true
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE sending_domains
  SET bounce_count = bounce_count + 1,
      last_reset_at = CASE WHEN last_reset_at IS NULL OR last_reset_at < NOW() - INTERVAL '24 hours' THEN NOW() ELSE last_reset_at END
  WHERE brand_id = p_brand_id AND domain = p_domain;

  IF FOUND AND p_is_hard THEN
    UPDATE sending_domains
    SET is_active = false,
        disabled_reason = 'hard_bounce',
        disabled_at = NOW()
    WHERE brand_id = p_brand_id AND domain = p_domain
    AND (bounce_count::numeric / NULLIF(sent_today, 0)) > 0.02;
  END IF;
END;
$$;

-- ========================================================
-- Create rpc_update_signal_source_performance
-- ========================================================
DROP FUNCTION IF EXISTS public.rpc_update_signal_source_performance(uuid, uuid, int, int, int);

CREATE OR REPLACE FUNCTION public.rpc_update_signal_source_performance(
  p_brand_id uuid, 
  p_source_id uuid, 
  p_send_delta int DEFAULT 0, 
  p_reply_delta int DEFAULT 0, 
  p_bounce_delta int DEFAULT 0
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO signal_source_performance (source_id, brand_id, sends, replies, bounces, last_updated)
  VALUES (p_source_id, p_brand_id, p_send_delta, p_reply_delta, p_bounce_delta, now())
  ON CONFLICT (source_id, brand_id) DO UPDATE SET
    sends = signal_source_performance.sends + p_send_delta,
    replies = signal_source_performance.replies + p_reply_delta,
    bounces = signal_source_performance.bounces + p_bounce_delta,
    last_updated = now();
END;
$$;

-- ========================================================
-- B12: Drop Overly Broad RLS Policies
-- ========================================================
DROP POLICY IF EXISTS "Allow all authenticated" ON public.activity_logs;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.audit_logs;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.brand_discovery_sources;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.brand_profiles;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.client_api_keys;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.client_members;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.client_settings;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.client_webhooks;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.clients;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.companies;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.dead_letter_queue;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.discovered_companies;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.discovered_contacts;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.discovery_sources;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.email_events;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.inbound_events;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.leads;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.messages;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.notification_preferences;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.outbound_events;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.replies;
DROP POLICY IF EXISTS "Allow all authenticated" ON public.sent_messages;

-- ========================================================
-- Migration completed
-- ========================================================